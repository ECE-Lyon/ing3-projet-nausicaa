package Main;

public class GUI_Manager {
    public static void main(String[] args)
    {
        GUI_Employee a = new GUI_Employee();
    }
}