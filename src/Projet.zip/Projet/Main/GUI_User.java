package Main;

public class GUI_User {
    public static void main(String[] args)
    {
        GUI_Login a = new GUI_Login();
    }
}